﻿namespace Tools
{
    public interface IStringIdItem
    {
        string Id { get; }
    }
}