using System;
using System.Windows;

[assembly: CLSCompliant(true)]

namespace JoinerSplitter
{
    /// <summary>
    ///     Interaction logic for App.xaml
    /// </summary>
    public partial class App
    {
    }
}