namespace JoinerSplitter
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class ListViewInsertMarkAdornerView
    {
        public ListViewInsertMarkAdornerView()
        {
            InitializeComponent();
        }
    }
}